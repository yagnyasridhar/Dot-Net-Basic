﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Equal
{ 
    public class Customer
    {       
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public override bool Equals(object obj)
        {
            Customer c1 = (Customer)obj;
            return this.FirstName == c1.FirstName && this.LastName == c1.LastName;
        }
        //public override int GetHashCode()
        //{
        //    return this.FirstName.GetHashCode() ^ this.LastName.GetHashCode();
        //}
    }
    class Program
    {
        static void Main(string[] args)
        {
            Customer customer = new Customer();
            customer.FirstName = "Sridhar";
            customer.LastName = "Shankar";

            Customer customer1 = new Customer();
            customer1.FirstName = "Sridhar";
            customer1.LastName = "Shankar";

            bool d = customer.Equals(customer1);
        }
    }
}
